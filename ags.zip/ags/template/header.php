<div class="header">

	<!-- Navmenu Mobile Toggle Button -->
	<a href="#" class="header-menutoggle" id="header-menutoggle">Menu</a>

	<!-- Logotype -->
	<p class="header-logo">
		<a href="index.html"><img class="img-top-logo" src="asset/ags-logo.png" alt=""></a>
	</p>

	<!-- Navmenu - start -->
	<nav id="top-menu">
		<ul>
		    <?php
		    $nav_page = array(
		    	'index',
		    	'about',
		    	'catalog',
		    	'contacts',
		    	'#'
		    	);
		    $nav_label = array(
		    	'HOME',
		    	'ABOUT US',
		    	'CATALOG',
		    	'CONTACT US',
		    	'<img src="img/search-dark.png" alt="">'
		    	);

		    for($r = 0; $r<count($nav_label); $r++){
		    	echo '<li'; if($nav_page[$r] == $checkin){ echo ' class="active"'; } echo '><a href="'.$nav_page[$r].'.php">'.$nav_label[$r].'</a></li>';
		    }
		    ?>
		</ul>
	</nav>
	<!-- Navmenu - end -->

</div>