<?php
require('template/setting.php');
$checkin = 'about';
?>
<!doctype html>
<html lang="en">
<head>

<meta charset="UTF-8">
<title><?php echo titlePage('about'); ?></title>
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<link href='https://fonts.googleapis.com/css?family=Open+Sans:400,400italic,600,600italic,700,700italic,300italic,300&amp;subset=latin,cyrillic' rel='stylesheet' type='text/css'>
<link href='https://fonts.googleapis.com/css?family=Montserrat:400,700&amp;subset=latin,cyrillic' rel='stylesheet' type='text/css'>

<link rel="stylesheet" href="css/font-awesome.min.css">
<link rel="stylesheet" href="css/zabuto_calendar.css">
<link rel="stylesheet" href="css/flexslider.css">
<link rel="stylesheet" href="css/jquery.fancybox.css">
<link rel="stylesheet" href="css/ion.rangeSlider.css">
<link rel="stylesheet" href="css/ion.rangeSlider.skinFlat.css">
<link rel="stylesheet" href="css/style.css">
<link rel="stylesheet" href="css/media.css">


<!--[if lt IE 9]>
<script src="js/html5shiv.js"></script>
<![endif]-->

</head>
<body>



<!-- Header - start -->
<?php require_once('template/header.php'); ?>
<!-- Header - end -->

<!-- Main Content - start -->
<main>

<!-- Breadcrumbs -->
<div class="b-crumbs-wrap">
	<div class="cont b-crumbs">
		<ul>
			<li>
				<a href="index.php">Motor</a>
			</li>
			<li>
				<span>About us</span>
			</li>
		</ul>
	</div>
</div>

<div class="cont maincont">
	<h1><span>About us</span></h1>
	<span class="maincont-line1 maincont-line12"></span>
	<span class="maincont-line2 maincont-line22"></span>

	<!-- Slider About us - start -->
	<div class="flexslider pagecont aboutus" id="aboutus">
		<ul class="slides">
			<li class="aboutus-slide">
				<p class="aboutus-img">
					<img src="http://placehold.it/470x400" alt="">
				</p>
				<div class="aboutus-cont">
					<h3>Suspendisse convallis, dolor ac eleifend faucibus, arcu massa pellentesque justo</h3>
					<p>Nullam quis tempor ligula, nec ornare dui. Sed fermentum magna ipsum, sit amet malesuada ante pretium in. Maecenas hendrerit purus tincidunt feugiat iaculis. Nunc facilisis id nunc blandit interdum. Sed convallis vel enim sit amet dictum. Donec tincidunt dolor semper fermentum lacinia. Morbi dolor ex, rhoncus quis nibh in, porta facilisis metus. Donec pulvinar bibendum lobortis. Vivamus consequat eros sit amet lorem tristique, sit amet viverra dolor maximus. Proin est nisi, ornare eu gravida eget, fringilla sit amet augue. Morbi arcu ante, vestibulum ac metus sed, commodo sollicitudin ligula. Duis justo massa, rutrum vel lectus sit amet, cursus pretium nulla.</p>
				</div>
			</li>
			<li class="aboutus-slide">
				<p class="aboutus-img">
					<img src="http://placehold.it/500x380" alt="">
				</p>
				<div class="aboutus-cont">
					<h3>Nunc facilisis id nunc blandit interdum</h3>
					<p>Nullam quis tempor ligula, nec ornare dui. Sed fermentum magna ipsum, sit amet malesuada ante pretium in. Maecenas hendrerit purus tincidunt feugiat iaculis. Nunc facilisis id nunc blandit interdum. Sed convallis vel enim sit amet dictum. Donec tincidunt dolor semper fermentum lacinia. Morbi dolor ex, rhoncus quis nibh in, porta facilisis metus. Donec pulvinar bibendum lobortis. Vivamus consequat eros sit amet lorem tristique, sit amet viverra dolor maximus. Proin est nisi, ornare eu gravida eget, fringilla sit amet augue. Morbi arcu ante, vestibulum ac metus sed, commodo sollicitudin ligula. Duis justo massa, rutrum vel lectus sit amet, cursus pretium nulla.</p>
				</div>
			</li>
			<li class="aboutus-slide">
				<p class="aboutus-img">
					<img src="http://placehold.it/470x320" alt="">
				</p>
				<div class="aboutus-cont">
					<h3>Maecenas hendrerit purus tincidunt feugiat iaculis</h3>
					<p>Nullam quis tempor ligula, nec ornare dui. Sed fermentum magna ipsum, sit amet malesuada ante pretium in. Maecenas hendrerit purus tincidunt feugiat iaculis. Donec tincidunt dolor semper fermentum lacinia. Morbi dolor ex, rhoncus quis nibh in, porta facilisis metus. Donec pulvinar bibendum lobortis. Vivamus consequat eros sit amet lorem tristique, sit amet viverra dolor maximus. Proin est nisi, ornare eu gravida eget, fringilla sit amet augue. </p>
				</div>
			</li>
		</ul>
	</div>
	<!-- Slider About us - end -->

</div>

<div class="cont maincont">
	<h1><span>Videos</span></h1>
	<span class="maincont-line1 maincont-line12"></span>
	<span class="maincont-line2 maincont-line22"></span>

	<!-- Gallery About us - start -->
	<ul class="about-gallery" id="about-gallery">
		<li class="grid-sizer"></li>
		<li class="grid-item">
			<a class="fancy-img" data-fancybox-group="about" href="img/logo.png">
				<span>
					<img src="http://placehold.it/292x176" alt="">
				</span>
			</a>
		</li>
		<li class="grid-item">
			<a class="fancy-img about-video" data-fancybox-group="about" href="https://www.youtube.com/watch?v=L1bruVSY8LE&fs=1&autoplay=1">
				<span>
					<img src="http://placehold.it/292x176" alt="">
				</span>
			</a>
		</li>
		<li class="grid-item">
			<a class="fancy-img" data-fancybox-group="about" href="img/logo.png">
				<span>
					<img src="http://placehold.it/292x176" alt="">
				</span>
			</a>
		</li>
		<li class="grid-item">
			<a class="fancy-img" data-fancybox-group="about" href="img/logo.png">
				<span>
					<img src="http://placehold.it/292x176" alt="">
				</span>
			</a>
		</li>
		<li class="grid-item">
			<a class="fancy-img" data-fancybox-group="about" href="img/logo.png">
				<span>
					<img src="http://placehold.it/292x176" alt="">
				</span>
			</a>
		</li>
		<li class="grid-item">
			<a class="fancy-img" data-fancybox-group="about" href="img/logo.png">
				<span>
					<img src="http://placehold.it/292x176" alt="">
				</span>
			</a>
		</li>
		<li class="grid-item">
			<a class="fancy-img about-video" data-fancybox-group="about" href="https://www.youtube.com/watch?v=L1bruVSY8LE&fs=1&autoplay=1">
				<span>
					<img src="http://placehold.it/292x176" alt="">
				</span>
			</a>
		</li>
		<li class="grid-item">
			<a class="fancy-img" data-fancybox-group="about" href="img/logo.png">
				<span>
					<img src="http://placehold.it/292x176" alt="">
				</span>
			</a>
		</li>
	</ul>
	<!-- Gallery About us - end -->

</div>

</main>
<!-- Main Content - end -->


<!-- Footer - start -->
<?php require_once('template/footer.php'); ?>
<!-- Footer - end -->


<!-- Modal Form -->
<div id="modal-form" class="modal-form">
	<p class="modal-form-ttl">Contact Us</p>
	<form action="#" class="form-validate">
		<input data-required="text" type="text" placeholder="Name" name="name2">
		<input data-required="text" type="text" placeholder="Phone" name="phone2">
		<input data-required="text" data-required-email="email" type="text" placeholder="Email" name="email2">
		<textarea placeholder="Your message" name="mess2"></textarea>
		<input type="submit" value="Send">
	</form>
</div>

<script src="js/jquery-1.12.3.min.js"></script>
<script src="js/jquery.fractionslider.min.js"></script>
<script src="js/fancybox/fancybox.js"></script>
<script src="js/fancybox/helpers/jquery.fancybox-thumbs.js"></script>
<script src="js/jquery.flexslider-min.js"></script>
<script src="js/masonry.pkgd.min.js"></script>
<script src="js/main.js"></script>

</body>
</html>